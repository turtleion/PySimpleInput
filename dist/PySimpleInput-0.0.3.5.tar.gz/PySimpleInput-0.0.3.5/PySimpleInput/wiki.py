
def wiki():
    print("Wiki has moved to README.md as Docs")
